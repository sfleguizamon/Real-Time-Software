/*
 * app.h
 *
 *  Created on: Jun 22, 2021
 *      Author: stgol
 */

#ifndef INC_APP_H_
#define INC_APP_H_

void StartupTask (void *p_arg);

#endif /* INC_APP_H_ */
